﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLMWindowsFormsApp1
{
    public partial class FLM : Form
    {
        public FLM()
        {
            InitializeComponent();
        }

        private void BranchBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.branchBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.productBranchDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'productBranchDataSet.Product' table. You can move, or remove it, as needed.
            //this.productTableAdapter.Fill(this.productBranchDataSet.Product);
            // TODO: This line of code loads data into the 'productBranchDataSet.BranchProduct' table. You can move, or remove it, as needed.
            this.branchProductTableAdapter.Fill(this.productBranchDataSet.BranchProduct);

        }

        private void IDLabel_Click(object sender, EventArgs e)
        {

        }

        private void IDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void NameLabel_Click(object sender, EventArgs e)
        {

        }

        private void NameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void TelephoneNumberLabel_Click(object sender, EventArgs e)
        {

        }

        private void TelephoneNumberTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void OpenDateLabel_Click(object sender, EventArgs e)
        {

        }

        private void OpenDateDateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void WeightedItemCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Save_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void SaveLinkBranchProduct_Click(object sender, EventArgs e)
        {
            //Peform data validation
            this.Validate();

            //ensure any temp changes are made final
           
        }

        private void SaveProduct_Click(object sender, EventArgs e)
        {
            this.Validate();

        }
    }
}
