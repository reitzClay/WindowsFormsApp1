﻿namespace FLMWindowsFormsApp1
{
    partial class FLM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iDLabelBranch;
            System.Windows.Forms.Label nameLabelBranch;
            System.Windows.Forms.Label telephoneNumberLabel;
            System.Windows.Forms.Label openDateLabel;
            System.Windows.Forms.Label branchIDLabel;
            System.Windows.Forms.Label productIDLabel;
            System.Windows.Forms.Label iDLabel1Product;
            System.Windows.Forms.Label nameLabel1Product;
            System.Windows.Forms.Label weightedItemLabel;
            System.Windows.Forms.Label suggestedSellingPriceLabel;
            this.branchBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productBranchDataSet = new FLMWindowsFormsApp1.ProductBranchDataSet();
            this.branchTableAdapter = new FLMWindowsFormsApp1.ProductBranchDataSetTableAdapters.BranchTableAdapter();
            this.tableAdapterManager = new FLMWindowsFormsApp1.ProductBranchDataSetTableAdapters.TableAdapterManager();
            this.iDTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.telephoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.openDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.branchProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.branchProductTableAdapter = new FLMWindowsFormsApp1.ProductBranchDataSetTableAdapters.BranchProductTableAdapter();
            this.branchIDTextBox = new System.Windows.Forms.TextBox();
            this.productIDTextBox = new System.Windows.Forms.TextBox();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productTableAdapter = new FLMWindowsFormsApp1.ProductBranchDataSetTableAdapters.ProductTableAdapter();
            this.iDTextBox1 = new System.Windows.Forms.TextBox();
            this.nameTextBox1 = new System.Windows.Forms.TextBox();
            this.weightedItemCheckBox = new System.Windows.Forms.CheckBox();
            this.suggestedSellingPriceTextBox = new System.Windows.Forms.TextBox();
            this.SaveBranch = new System.Windows.Forms.Button();
            this.DeleteBranch = new System.Windows.Forms.Button();
            this.SaveProduct = new System.Windows.Forms.Button();
            this.DeleteProduct = new System.Windows.Forms.Button();
            this.SaveLinkBranchProduct = new System.Windows.Forms.Button();
            this.DeleteProductBranchLink = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telephoneNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightedItemDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.suggestedSellingPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.branchIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            iDLabelBranch = new System.Windows.Forms.Label();
            nameLabelBranch = new System.Windows.Forms.Label();
            telephoneNumberLabel = new System.Windows.Forms.Label();
            openDateLabel = new System.Windows.Forms.Label();
            branchIDLabel = new System.Windows.Forms.Label();
            productIDLabel = new System.Windows.Forms.Label();
            iDLabel1Product = new System.Windows.Forms.Label();
            nameLabel1Product = new System.Windows.Forms.Label();
            weightedItemLabel = new System.Windows.Forms.Label();
            suggestedSellingPriceLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBranchDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.branchProductBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // branchBindingSource
            // 
            this.branchBindingSource.DataMember = "Branch";
            this.branchBindingSource.DataSource = this.productBranchDataSet;
            // 
            // productBranchDataSet
            // 
            this.productBranchDataSet.DataSetName = "ProductBranchDataSet";
            this.productBranchDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // branchTableAdapter
            // 
            this.branchTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BranchProductTableAdapter = this.branchProductTableAdapter;
            this.tableAdapterManager.BranchTableAdapter = this.branchTableAdapter;
            this.tableAdapterManager.ProductTableAdapter = this.productTableAdapter;
            this.tableAdapterManager.UpdateOrder = FLMWindowsFormsApp1.ProductBranchDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // iDLabelBranch
            // 
            iDLabelBranch.AutoSize = true;
            iDLabelBranch.Location = new System.Drawing.Point(28, 234);
            iDLabelBranch.Name = "iDLabelBranch";
            iDLabelBranch.Size = new System.Drawing.Size(55, 13);
            iDLabelBranch.TabIndex = 0;
            iDLabelBranch.Text = "ID:Branch";
            iDLabelBranch.Click += new System.EventHandler(this.IDLabel_Click);
            // 
            // iDTextBox
            // 
            this.iDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.branchBindingSource, "ID", true));
            this.iDTextBox.Location = new System.Drawing.Point(155, 231);
            this.iDTextBox.Name = "iDTextBox";
            this.iDTextBox.Size = new System.Drawing.Size(200, 20);
            this.iDTextBox.TabIndex = 1;
            this.iDTextBox.TextChanged += new System.EventHandler(this.IDTextBox_TextChanged);
            // 
            // nameLabelBranch
            // 
            nameLabelBranch.AutoSize = true;
            nameLabelBranch.Location = new System.Drawing.Point(28, 260);
            nameLabelBranch.Name = "nameLabelBranch";
            nameLabelBranch.Size = new System.Drawing.Size(72, 13);
            nameLabelBranch.TabIndex = 2;
            nameLabelBranch.Text = "Name:Branch";
            nameLabelBranch.Click += new System.EventHandler(this.NameLabel_Click);
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.branchBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(155, 257);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(200, 20);
            this.nameTextBox.TabIndex = 3;
            this.nameTextBox.TextChanged += new System.EventHandler(this.NameTextBox_TextChanged);
            // 
            // telephoneNumberLabel
            // 
            telephoneNumberLabel.AutoSize = true;
            telephoneNumberLabel.Location = new System.Drawing.Point(28, 286);
            telephoneNumberLabel.Name = "telephoneNumberLabel";
            telephoneNumberLabel.Size = new System.Drawing.Size(101, 13);
            telephoneNumberLabel.TabIndex = 4;
            telephoneNumberLabel.Text = "Telephone Number:";
            telephoneNumberLabel.Click += new System.EventHandler(this.TelephoneNumberLabel_Click);
            // 
            // telephoneNumberTextBox
            // 
            this.telephoneNumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.branchBindingSource, "TelephoneNumber", true));
            this.telephoneNumberTextBox.Location = new System.Drawing.Point(155, 283);
            this.telephoneNumberTextBox.Name = "telephoneNumberTextBox";
            this.telephoneNumberTextBox.Size = new System.Drawing.Size(200, 20);
            this.telephoneNumberTextBox.TabIndex = 5;
            this.telephoneNumberTextBox.TextChanged += new System.EventHandler(this.TelephoneNumberTextBox_TextChanged);
            // 
            // openDateLabel
            // 
            openDateLabel.AutoSize = true;
            openDateLabel.Location = new System.Drawing.Point(28, 313);
            openDateLabel.Name = "openDateLabel";
            openDateLabel.Size = new System.Drawing.Size(62, 13);
            openDateLabel.TabIndex = 6;
            openDateLabel.Text = "Open Date:";
            openDateLabel.Click += new System.EventHandler(this.OpenDateLabel_Click);
            // 
            // openDateDateTimePicker
            // 
            this.openDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.branchBindingSource, "OpenDate", true));
            this.openDateDateTimePicker.Location = new System.Drawing.Point(155, 309);
            this.openDateDateTimePicker.Name = "openDateDateTimePicker";
            this.openDateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.openDateDateTimePicker.TabIndex = 7;
            this.openDateDateTimePicker.ValueChanged += new System.EventHandler(this.OpenDateDateTimePicker_ValueChanged);
            // 
            // branchProductBindingSource
            // 
            this.branchProductBindingSource.DataMember = "BranchProduct";
            this.branchProductBindingSource.DataSource = this.productBranchDataSet;
            // 
            // branchProductTableAdapter
            // 
            this.branchProductTableAdapter.ClearBeforeFill = true;
            // 
            // branchIDLabel
            // 
            branchIDLabel.AutoSize = true;
            branchIDLabel.Location = new System.Drawing.Point(68, 446);
            branchIDLabel.Name = "branchIDLabel";
            branchIDLabel.Size = new System.Drawing.Size(58, 13);
            branchIDLabel.TabIndex = 8;
            branchIDLabel.Text = "Branch ID:";
            // 
            // branchIDTextBox
            // 
            this.branchIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.branchProductBindingSource, "BranchID", true));
            this.branchIDTextBox.Location = new System.Drawing.Point(155, 443);
            this.branchIDTextBox.Name = "branchIDTextBox";
            this.branchIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.branchIDTextBox.TabIndex = 9;
            // 
            // productIDLabel
            // 
            productIDLabel.AutoSize = true;
            productIDLabel.Location = new System.Drawing.Point(68, 472);
            productIDLabel.Name = "productIDLabel";
            productIDLabel.Size = new System.Drawing.Size(61, 13);
            productIDLabel.TabIndex = 10;
            productIDLabel.Text = "Product ID:";
            // 
            // productIDTextBox
            // 
            this.productIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.branchProductBindingSource, "ProductID", true));
            this.productIDTextBox.Location = new System.Drawing.Point(155, 469);
            this.productIDTextBox.Name = "productIDTextBox";
            this.productIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.productIDTextBox.TabIndex = 11;
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.productBranchDataSet;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // iDLabel1Product
            // 
            iDLabel1Product.AutoSize = true;
            iDLabel1Product.Location = new System.Drawing.Point(41, 26);
            iDLabel1Product.Name = "iDLabel1Product";
            iDLabel1Product.Size = new System.Drawing.Size(58, 13);
            iDLabel1Product.TabIndex = 12;
            iDLabel1Product.Text = "ID:Product";
            // 
            // iDTextBox1
            // 
            this.iDTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "ID", true));
            this.iDTextBox1.Location = new System.Drawing.Point(155, 23);
            this.iDTextBox1.Name = "iDTextBox1";
            this.iDTextBox1.Size = new System.Drawing.Size(104, 20);
            this.iDTextBox1.TabIndex = 13;
            // 
            // nameLabel1Product
            // 
            nameLabel1Product.AutoSize = true;
            nameLabel1Product.Location = new System.Drawing.Point(24, 52);
            nameLabel1Product.Name = "nameLabel1Product";
            nameLabel1Product.Size = new System.Drawing.Size(75, 13);
            nameLabel1Product.TabIndex = 14;
            nameLabel1Product.Text = "Name:Product";
            // 
            // nameTextBox1
            // 
            this.nameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "Name", true));
            this.nameTextBox1.Location = new System.Drawing.Point(155, 49);
            this.nameTextBox1.Name = "nameTextBox1";
            this.nameTextBox1.Size = new System.Drawing.Size(104, 20);
            this.nameTextBox1.TabIndex = 15;
            // 
            // weightedItemLabel
            // 
            weightedItemLabel.AutoSize = true;
            weightedItemLabel.Location = new System.Drawing.Point(24, 80);
            weightedItemLabel.Name = "weightedItemLabel";
            weightedItemLabel.Size = new System.Drawing.Size(79, 13);
            weightedItemLabel.TabIndex = 16;
            weightedItemLabel.Text = "Weighted Item:";
            // 
            // weightedItemCheckBox
            // 
            this.weightedItemCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.productBindingSource, "WeightedItem", true));
            this.weightedItemCheckBox.Location = new System.Drawing.Point(155, 75);
            this.weightedItemCheckBox.Name = "weightedItemCheckBox";
            this.weightedItemCheckBox.Size = new System.Drawing.Size(104, 24);
            this.weightedItemCheckBox.TabIndex = 17;
            this.weightedItemCheckBox.Text = "checkBox1";
            this.weightedItemCheckBox.UseVisualStyleBackColor = true;
            this.weightedItemCheckBox.CheckedChanged += new System.EventHandler(this.WeightedItemCheckBox_CheckedChanged);
            // 
            // suggestedSellingPriceLabel
            // 
            suggestedSellingPriceLabel.AutoSize = true;
            suggestedSellingPriceLabel.Location = new System.Drawing.Point(24, 108);
            suggestedSellingPriceLabel.Name = "suggestedSellingPriceLabel";
            suggestedSellingPriceLabel.Size = new System.Drawing.Size(122, 13);
            suggestedSellingPriceLabel.TabIndex = 18;
            suggestedSellingPriceLabel.Text = "Suggested Selling Price:";
            // 
            // suggestedSellingPriceTextBox
            // 
            this.suggestedSellingPriceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "SuggestedSellingPrice", true));
            this.suggestedSellingPriceTextBox.Location = new System.Drawing.Point(155, 105);
            this.suggestedSellingPriceTextBox.Name = "suggestedSellingPriceTextBox";
            this.suggestedSellingPriceTextBox.Size = new System.Drawing.Size(104, 20);
            this.suggestedSellingPriceTextBox.TabIndex = 19;
            // 
            // SaveBranch
            // 
            this.SaveBranch.Location = new System.Drawing.Point(155, 346);
            this.SaveBranch.Name = "SaveBranch";
            this.SaveBranch.Size = new System.Drawing.Size(75, 23);
            this.SaveBranch.TabIndex = 20;
            this.SaveBranch.Text = "Save";
            this.SaveBranch.UseVisualStyleBackColor = true;
            this.SaveBranch.Click += new System.EventHandler(this.Save_Click);
            // 
            // DeleteBranch
            // 
            this.DeleteBranch.Location = new System.Drawing.Point(250, 346);
            this.DeleteBranch.Name = "DeleteBranch";
            this.DeleteBranch.Size = new System.Drawing.Size(75, 23);
            this.DeleteBranch.TabIndex = 21;
            this.DeleteBranch.Text = "Delete";
            this.DeleteBranch.UseVisualStyleBackColor = true;
            this.DeleteBranch.Click += new System.EventHandler(this.Button1_Click);
            // 
            // SaveProduct
            // 
            this.SaveProduct.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.productBindingSource, "Name", true));
            this.SaveProduct.Location = new System.Drawing.Point(155, 142);
            this.SaveProduct.Name = "SaveProduct";
            this.SaveProduct.Size = new System.Drawing.Size(75, 23);
            this.SaveProduct.TabIndex = 22;
            this.SaveProduct.Text = "Save";
            this.SaveProduct.UseVisualStyleBackColor = true;
            this.SaveProduct.Click += new System.EventHandler(this.SaveProduct_Click);
            // 
            // DeleteProduct
            // 
            this.DeleteProduct.Location = new System.Drawing.Point(250, 142);
            this.DeleteProduct.Name = "DeleteProduct";
            this.DeleteProduct.Size = new System.Drawing.Size(75, 23);
            this.DeleteProduct.TabIndex = 23;
            this.DeleteProduct.Text = "Delete";
            this.DeleteProduct.UseVisualStyleBackColor = true;
            // 
            // SaveLinkBranchProduct
            // 
            this.SaveLinkBranchProduct.Location = new System.Drawing.Point(155, 495);
            this.SaveLinkBranchProduct.Name = "SaveLinkBranchProduct";
            this.SaveLinkBranchProduct.Size = new System.Drawing.Size(75, 23);
            this.SaveLinkBranchProduct.TabIndex = 24;
            this.SaveLinkBranchProduct.Text = "Save";
            this.SaveLinkBranchProduct.UseVisualStyleBackColor = true;
            this.SaveLinkBranchProduct.Click += new System.EventHandler(this.SaveLinkBranchProduct_Click);
            // 
            // DeleteProductBranchLink
            // 
            this.DeleteProductBranchLink.Location = new System.Drawing.Point(250, 495);
            this.DeleteProductBranchLink.Name = "DeleteProductBranchLink";
            this.DeleteProductBranchLink.Size = new System.Drawing.Size(75, 23);
            this.DeleteProductBranchLink.TabIndex = 25;
            this.DeleteProductBranchLink.Text = "Delete";
            this.DeleteProductBranchLink.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.telephoneNumberDataGridViewTextBoxColumn,
            this.openDateDataGridViewTextBoxColumn});
            this.dataGridView1.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.branchBindingSource, "ID", true));
            this.dataGridView1.DataSource = this.branchBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(396, 231);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(546, 98);
            this.dataGridView1.TabIndex = 26;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // telephoneNumberDataGridViewTextBoxColumn
            // 
            this.telephoneNumberDataGridViewTextBoxColumn.DataPropertyName = "TelephoneNumber";
            this.telephoneNumberDataGridViewTextBoxColumn.HeaderText = "TelephoneNumber";
            this.telephoneNumberDataGridViewTextBoxColumn.Name = "telephoneNumberDataGridViewTextBoxColumn";
            // 
            // openDateDataGridViewTextBoxColumn
            // 
            this.openDateDataGridViewTextBoxColumn.DataPropertyName = "OpenDate";
            this.openDateDataGridViewTextBoxColumn.HeaderText = "OpenDate";
            this.openDateDataGridViewTextBoxColumn.Name = "openDateDataGridViewTextBoxColumn";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn1,
            this.nameDataGridViewTextBoxColumn1,
            this.weightedItemDataGridViewCheckBoxColumn,
            this.suggestedSellingPriceDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.productBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(396, 31);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(529, 134);
            this.dataGridView2.TabIndex = 27;
            // 
            // iDDataGridViewTextBoxColumn1
            // 
            this.iDDataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn1.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn1.Name = "iDDataGridViewTextBoxColumn1";
            // 
            // nameDataGridViewTextBoxColumn1
            // 
            this.nameDataGridViewTextBoxColumn1.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn1.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn1.Name = "nameDataGridViewTextBoxColumn1";
            // 
            // weightedItemDataGridViewCheckBoxColumn
            // 
            this.weightedItemDataGridViewCheckBoxColumn.DataPropertyName = "WeightedItem";
            this.weightedItemDataGridViewCheckBoxColumn.HeaderText = "WeightedItem";
            this.weightedItemDataGridViewCheckBoxColumn.Name = "weightedItemDataGridViewCheckBoxColumn";
            // 
            // suggestedSellingPriceDataGridViewTextBoxColumn
            // 
            this.suggestedSellingPriceDataGridViewTextBoxColumn.DataPropertyName = "SuggestedSellingPrice";
            this.suggestedSellingPriceDataGridViewTextBoxColumn.HeaderText = "SuggestedSellingPrice";
            this.suggestedSellingPriceDataGridViewTextBoxColumn.Name = "suggestedSellingPriceDataGridViewTextBoxColumn";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToOrderColumns = true;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.branchIDDataGridViewTextBoxColumn,
            this.productIDDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.branchProductBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(396, 435);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(343, 83);
            this.dataGridView3.TabIndex = 28;
            // 
            // branchIDDataGridViewTextBoxColumn
            // 
            this.branchIDDataGridViewTextBoxColumn.DataPropertyName = "BranchID";
            this.branchIDDataGridViewTextBoxColumn.HeaderText = "BranchID";
            this.branchIDDataGridViewTextBoxColumn.Name = "branchIDDataGridViewTextBoxColumn";
            // 
            // productIDDataGridViewTextBoxColumn
            // 
            this.productIDDataGridViewTextBoxColumn.DataPropertyName = "ProductID";
            this.productIDDataGridViewTextBoxColumn.HeaderText = "ProductID";
            this.productIDDataGridViewTextBoxColumn.Name = "productIDDataGridViewTextBoxColumn";
            // 
            // FLM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1153, 628);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.DeleteProductBranchLink);
            this.Controls.Add(this.SaveLinkBranchProduct);
            this.Controls.Add(this.DeleteProduct);
            this.Controls.Add(this.SaveProduct);
            this.Controls.Add(this.DeleteBranch);
            this.Controls.Add(this.SaveBranch);
            this.Controls.Add(iDLabel1Product);
            this.Controls.Add(this.iDTextBox1);
            this.Controls.Add(nameLabel1Product);
            this.Controls.Add(this.nameTextBox1);
            this.Controls.Add(weightedItemLabel);
            this.Controls.Add(this.weightedItemCheckBox);
            this.Controls.Add(suggestedSellingPriceLabel);
            this.Controls.Add(this.suggestedSellingPriceTextBox);
            this.Controls.Add(branchIDLabel);
            this.Controls.Add(this.branchIDTextBox);
            this.Controls.Add(productIDLabel);
            this.Controls.Add(this.productIDTextBox);
            this.Controls.Add(iDLabelBranch);
            this.Controls.Add(this.iDTextBox);
            this.Controls.Add(nameLabelBranch);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(telephoneNumberLabel);
            this.Controls.Add(this.telephoneNumberTextBox);
            this.Controls.Add(openDateLabel);
            this.Controls.Add(this.openDateDateTimePicker);
            this.Name = "FLM";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBranchDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.branchProductBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ProductBranchDataSet productBranchDataSet;
        private System.Windows.Forms.BindingSource branchBindingSource;
        private ProductBranchDataSetTableAdapters.BranchTableAdapter branchTableAdapter;
        private ProductBranchDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox iDTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox telephoneNumberTextBox;
        private System.Windows.Forms.DateTimePicker openDateDateTimePicker;
        private System.Windows.Forms.BindingSource branchProductBindingSource;
        private ProductBranchDataSetTableAdapters.BranchProductTableAdapter branchProductTableAdapter;
        private System.Windows.Forms.TextBox branchIDTextBox;
        private System.Windows.Forms.TextBox productIDTextBox;
        private System.Windows.Forms.BindingSource productBindingSource;
        private ProductBranchDataSetTableAdapters.ProductTableAdapter productTableAdapter;
        private System.Windows.Forms.TextBox iDTextBox1;
        private System.Windows.Forms.TextBox nameTextBox1;
        private System.Windows.Forms.CheckBox weightedItemCheckBox;
        private System.Windows.Forms.TextBox suggestedSellingPriceTextBox;
        private System.Windows.Forms.Button SaveBranch;
        private System.Windows.Forms.Button DeleteBranch;
        private System.Windows.Forms.Button SaveProduct;
        private System.Windows.Forms.Button DeleteProduct;
        private System.Windows.Forms.Button SaveLinkBranchProduct;
        private System.Windows.Forms.Button DeleteProductBranchLink;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telephoneNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn openDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn weightedItemDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suggestedSellingPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn branchIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn;
    }
}

